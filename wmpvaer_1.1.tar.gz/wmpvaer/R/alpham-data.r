#' alpham Dataset for wmpvaer
#'
#' Dataset needed for the operation of  R function "oneway_mss".   
#' 
#' @docType data
#' @usage data(alpham)
#' @format typeof(alpham)=="list"
#' @keywords datasets
#' @references none  
 "alpham"